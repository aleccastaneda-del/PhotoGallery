function selectDelete ({selectedImage , notify});

function handleDelete() {
    fetch(`http://127.0.0.1:5500/Delete`, { method: "DELETE" })
        .then(() => notify({ action: "delete", selectedImage }))
        .catch(error => notify({ action: "delete", error }));
};

