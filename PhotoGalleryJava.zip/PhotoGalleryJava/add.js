const input = document.getElementById("imagefile");
const userInput = document.getElementById("add");
const errorText = document.getElementById("errorText")

userInput.addEventListener("click", function() {
    input.click();
  });

input.addEventListener('change', function(){
    const reader = new FileReader();

     reader.addEventListener('load', function(){
         userInput = reader.result;
            input.setAttribute('src', reader.result);
        });
    });
