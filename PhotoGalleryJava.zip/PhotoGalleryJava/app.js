// reference to gallery element id created
const gallery = document.getElementById('gallery');
// reference to popup element id created
const popup = document.getElementById('popup');
// reference to selectedImage element id created
const selectedImage = document.getElementById('selectedImage');
// created an array for the pictures placed into the application
const imageIndexes = [1,2,3,4,5,6,7,8];
// the index for the selected photo that'll later be appended.
const selectedIndex = null;

// the loop that iterates through the picture array and finds each picture
// based on the number associated with each picture
imageIndexes.forEach(i => {
    const image= document.createElement('img');
    image.src = `/Images/photo-${i}.jpg`;
    image.classList.add('galleryImage');

    // popup event listener for pictures
image.addEventListener('click', () => {
    popup.style.transform = 'translateY(0)';
    selectedImage.src = `/Images/photo-${i}.jpg`;
});
// adding the image to the gallery
    gallery.appendChild(image);
});

// makes the popup disappear after the image is deselected
popup.addEventListener('click', () => {
    popup.style.transform = 'translateY(-100%)'
    popup.src = '';
});



