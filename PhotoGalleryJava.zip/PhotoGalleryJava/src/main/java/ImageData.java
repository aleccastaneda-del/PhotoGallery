import javafx.scene.image.Image;

import javax.imageio.ImageTypeSpecifier;
import java.util.Date;

public class ImageData extends console{
    public ImageData(String name, Date dateAdded, Image isFavorite, com.sun.scenario.effect.ImageData source, ImageTypeSpecifier filetype) {
        super(name, dateAdded, isFavorite, source, filetype);
    }

    @Override
    public String getName() {
        return super.getName();
    }

    @Override
    public void setName(String name) {
        super.setName(name);
    }

    @Override
    public Date getDateAdded() {
        return super.getDateAdded();
    }

    @Override
    public void setDateAdded(Date dateAdded) {
        super.setDateAdded(dateAdded);
    }

    @Override
    public Image getIsFavorite() {
        return super.getIsFavorite();
    }

    @Override
    public void setIsFavorite(Image isFavorite) {
        super.setIsFavorite(isFavorite);
    }

    @Override
    public com.sun.scenario.effect.ImageData getSource() {
        return super.getSource();
    }

    @Override
    public void setSource(com.sun.scenario.effect.ImageData source) {
        super.setSource(source);
    }

    @Override
    public ImageTypeSpecifier getFiletype() {
        return super.getFiletype();
    }

    @Override
    public void setFiletype(ImageTypeSpecifier filetype) {
        super.setFiletype(filetype);
    }
}
