import com.sun.javafx.iio.ImageStorage;
import com.sun.scenario.effect.ImageData;
import javafx.scene.image.Image;

import javax.imageio.ImageTypeSpecifier;
import javax.swing.text.html.ImageView;
import java.util.Date;

public class console {

    public String Name;
    public Date DateAdded;
    public Image isFavorite;
    public ImageData Source;
    public ImageTypeSpecifier Filetype;

    public console(String name, Date dateAdded, Image isFavorite, ImageData source, ImageTypeSpecifier filetype) {
        Name = name;
        DateAdded = dateAdded;
        this.isFavorite = isFavorite;
        Source = source;
        Filetype = filetype;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public Date getDateAdded() {
        return DateAdded;
    }

    public void setDateAdded(Date dateAdded) {
        DateAdded = dateAdded;
    }

    public Image getIsFavorite() {
        return isFavorite;
    }

    public void setIsFavorite(Image isFavorite) {
        this.isFavorite = isFavorite;
    }

    public ImageData getSource() {
        return Source;
    }

    public void setSource(ImageData source) {
        Source = source;
    }

    public ImageTypeSpecifier getFiletype() {
        return Filetype;
    }

    public void setFiletype(ImageTypeSpecifier filetype) {
        Filetype = filetype;
    }

}
